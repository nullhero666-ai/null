# LUMILEX Word Arena v8 — Word Search Worlds

**Original playable UI update inspired by 19 user-provided references.** All eight existing game modes are preserved, with new mobile-first Word Search scene and navigation.

### What is implemented

- Immersive Word Search background illustration with **4 original SVG themes** (Coastline, Woodland, Golden Dunes, Bloom Garden) plus starlit peaks for daily/timed modes
- Compact word-target chips **above** a high-contrast puzzle grid on phones; colorful solved letters/words; 320–390px width support
- Chapter Map with 54 real puzzle levels, chapter locks and persisted completion
- Playable Daily Calendar, previous 90 days (today and earlier); UTC selected date; records completions by challenge date
- Hint (1), Reveal word (2 hints, assisted with 0 score), rotate board (free; transforms grid data so solutions stay valid)
- Pause/resume for non-online word modes with frozen timed clocks and AI move delays
- Improved rewards/celebration overlay with trophy ribbon and correct progress recording
- Home quick entry for Word Search Chapters and Daily Adventure
- All 8 v7 game modes remain, Classic 250 levels, Word Search 54, Crossword Logic 36
- Browser single-file solo game and Android Capacitor client assets; Python multiplayer reference backend

### What is not implemented

- No fake ads, payment popups, premium currency sales or copyrighted competitor graphics
- No production Android APK, App Store / Play Store release
- No authenticated global rankings; sample previews are labelled
- No hosted, horizontally scaled WSS multiplayer

### Run and install

See `START_HERE.md`. For portable browser play open `website/LUMILEX_v8_Play.html`. In this source tree `www/` is what Capacitor uses; `website/` serves the browser version. `backend/` contains an HTTP/WebSocket test server only.

### Tests performed for this release

- JavaScript syntax validation, Capacitor asset validation, puzzle-data validation
- Browser-rendered smoke checks at 360, 390, 1240 px (using injected local assets)
- Word Search rotate/reveal/solving and progression; pause/resume; Daily Calendar; Classic; Rankings; PvP room UI
- Python server test for 1v1, 2v2 and public 2v2 matchmaking on local loopback

Release is a **development build**, not production-certified.
