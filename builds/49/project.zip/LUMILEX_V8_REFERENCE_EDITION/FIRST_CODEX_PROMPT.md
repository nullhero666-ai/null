# Paste into Codex in VS Code

You are implementing LUMILEX Word Arena as a production-quality mobile game using the existing `www/` web client and Capacitor.

Read `AGENTS.md`, `README.md`, `docs/APP_CONVERSION_ROADMAP.md`, and audit the existing code before changes.

**Task 1:** Set up Android native project, validate Node/Capacitor/Android dependencies, and run the app in Android Studio. Implement safe-area/status bar and Android back button handling. Do not alter puzzle data or navigation semantics. Keep offline solo modes working and test mobile keyboard, touch and rotation.

**Task 2 after Task 1 passes:** Explain server/backend gaps. Create interfaces for authenticated cloud profiles, progress, secure PvP room connection, verified ratings and leaderboard. Do not fabricate success or replace missing backend with hardcoded live data.

Deliver incremental code edits, exact commands, test logs, and a remaining blocker list. Never mark a feature as working until it is exercised on the relevant platform.
