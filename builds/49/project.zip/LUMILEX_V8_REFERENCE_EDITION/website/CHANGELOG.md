# Changelog

## v7 — November 2026: Professional Ranking Arena + UI refinement

- Replaced the overly long ranking screen with one dashboard and scope-switchable leaderboard.
- Introduced a polished league emblem, seven-tier journey, sample podium, progress indicator and separate player metrics.
- Implemented interactive Global / Country / City filters and optional self-reported location settings.
- Marked **all leaderboard competitor data as sample data**; no unsupported claims of live global ranks.
- Corrected practice-rank messaging so XP and AI wins are not described as official competitive rating.
- Updated desktop max width, full-width hero treatment, mode cards and consistent visual spacing.
- Prioritized word targets above the board on small screens and collapsed long instructions.
- Bumped service worker cache key to ensure the updated design replaces cached older versions.
- Preserved all game modes, content data, existing local progress, PvP unlock rules and room server.
- Added automated ranking/responsiveness checks. Existing 15 tests plus 2 new tests passing; local server integration tests pass.

### Still not implemented

Real global/country/city leaderboards, account verification, durable cloud progress and globally scalable matchmaking infrastructure. These require a production backend, not simply a UI change.
