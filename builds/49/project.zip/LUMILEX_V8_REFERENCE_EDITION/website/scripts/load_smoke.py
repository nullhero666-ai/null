"""Small local smoke test, not a production capacity certification.
Usage: python scripts/load_smoke.py --base http://127.0.0.1:8765 --requests 150 --concurrency 20
"""
import argparse, asyncio, secrets, statistics, time
from urllib.parse import urlparse
import aiohttp

async def run(args):
    times=[];errors=[];sem=asyncio.Semaphore(args.concurrency)
    timeout=aiohttp.ClientTimeout(total=10)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        async def request(n):
            async with sem:
                start=time.perf_counter()
                try:
                    target='/' if n%5==0 else '/api/health' if n%5==1 else '/index.html' if n%5==2 else '/app.js' if n%5==3 else '/puzzles.json'
                    async with session.get(args.base+target) as response:
                        await response.read()
                        if response.status!=200:errors.append(f'HTTP {response.status} {target}')
                    times.append((time.perf_counter()-start)*1000)
                except Exception as exc:errors.append(str(exc))
        await asyncio.gather(*(request(i) for i in range(args.requests)))
        ws_url=args.base.replace('https://','wss://').replace('http://','ws://')+'/ws'
        # Test a handful of real guest WebSocket handshakes, one connection at a time.
        for _ in range(min(8,args.concurrency)):
            try:
                async with session.ws_connect(ws_url,heartbeat=15) as ws:
                    await ws.send_json({'type':'hello','name':'LoadTester','token':secrets.token_hex(24)})
                    message=await ws.receive_json(timeout=4)
                    if message.get('type')!='hello':errors.append('WebSocket handshake not acknowledged')
            except Exception as exc:errors.append('WS '+str(exc))
    times.sort()
    p95=times[min(len(times)-1,round(len(times)*.95))] if times else None
    print(f'HTTP requests: {args.requests}; concurrency: {args.concurrency}; failures: {len(errors)}; HTTP p95 observed: {p95:.1f} ms' if p95 else 'No requests completed')
    if errors:print('Errors:',errors[:5]);raise SystemExit(1)
    print('LOCAL SMOKE PASSED. This does not prove global scalability.')

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--base',default='http://127.0.0.1:8765');parser.add_argument('--requests',type=int,default=150);parser.add_argument('--concurrency',type=int,default=20)
    args=parser.parse_args()
    if args.requests<1 or args.concurrency<1 or args.concurrency>50:parser.error('Use positive requests and 1..50 concurrency')
    asyncio.run(run(args))
