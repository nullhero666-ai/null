from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
landing=(root/'landing.html').read_text().replace('<link rel="stylesheet" href="landing.css">','<style>'+(root/'landing.css').read_text()+'</style>').replace('<script src="landing.js" defer></script>','')
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 mobile=browser.new_page(viewport={'width':390,'height':844},device_scale_factor=2)
 mobile.set_content(landing,wait_until='load');mobile.add_script_tag(content=(root/'landing.js').read_text())
 mobile.screenshot(path=str(root/'previews'/'Intro_Mobile.png'),full_page=True)
 desktop=browser.new_page(viewport={'width':1280,'height':840},device_scale_factor=1)
 desktop.set_content(landing,wait_until='load');desktop.add_script_tag(content=(root/'landing.js').read_text())
 desktop.screenshot(path=str(root/'previews'/'Intro_Desktop.png'),full_page=False)
 game=browser.new_page(viewport={'width':390,'height':844},device_scale_factor=2)
 game.set_content((root/'LUMILEX_OFFLINE.html').read_text(),wait_until='load')
 game.screenshot(path=str(root/'previews'/'Game_Home_Mobile.png'),full_page=True)
 game.locator('[data-act="play-classic"]').click()
 game.screenshot(path=str(root/'previews'/'Classic_Level_Mobile.png'),full_page=False)
 for page in (mobile,desktop,game):
  print(page.url,page.evaluate('document.documentElement.scrollWidth - document.documentElement.clientWidth'))
 browser.close()
