"""Create a single-file version of LUMILEX for offline solo play."""
from pathlib import Path
import json
import base64
root=Path(__file__).parent
html=(root/'index.html').read_text()
css=(root/'style.css').read_text()
# Inline original chapter artwork so the exported HTML works from Downloads alone.
for asset in (root/'assets').glob('*.svg'):
    uri='data:image/svg+xml;base64,'+base64.b64encode(asset.read_bytes()).decode('ascii')
    css=css.replace('assets/'+asset.name,uri)
js=(root/'app.js').read_text()
inline={"classic":json.loads((root/'classic.json').read_text()),"search":json.loads((root/'puzzles.json').read_text()),"cross":json.loads((root/'crosswords.json').read_text())}
# Keep external web manifest out of the file:// version.
html=html.replace('<link rel="manifest" href="manifest.webmanifest">','').replace('<link rel="icon" href="icon-192.png">','')
html=html.replace('<link rel="stylesheet" href="style.css">','<style>'+css+'</style>')
html=html.replace('<script src="config.js"></script>','')
html=html.replace('<script src="app.js"></script>','<script>window.LUMILEX_DATA='+json.dumps(inline,separators=(',',':')).replace('</','<\\/')+';</script><script>'+js+'</script>')
(root/'LUMILEX_OFFLINE.html').write_text(html)
print('Offline HTML bytes', (root/'LUMILEX_OFFLINE.html').stat().st_size)
