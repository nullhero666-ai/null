# START HERE — LUMILEX Web v7

**Quickest playable option:** double-click `LUMILEX_v7_Play.html`. Press **Play now**. All six offline-capable modes are available.

**Full web site with rooms:** open the project in VS Code, open a terminal, and run:

```sh
python -m pip install -r requirements.txt
python server.py
```

Visit `http://127.0.0.1:8765/`. Press **Play now**. Private and public 1v1/2v2 rooms need multiple real browser sessions. PvP is a Classic Level 15 reward and 2v2 a Level 20 reward. Cloud deployment is **not yet configured**. Follow the guide in `docs/DEPLOYMENT.md` for a one-node beta and `docs/SCALING_ARCHITECTURE.md` for public-traffic development tasks.

**Read these first:** `README.md`, `docs/GAME_MODES_AND_RULES.md`, `docs/LAUNCH_CHECKLIST.md`, `AGENTS.md`.

**Codex prompt:** `docs/NEXT_CODEX_PROMPT.md`.
