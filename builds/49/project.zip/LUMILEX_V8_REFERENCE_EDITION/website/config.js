// Public runtime configuration. Safe to serve from a CDN; never put secrets here.
// Set a separate HTTPS/WSS match endpoint only after you have deployed one.
window.LUMILEX_WS_URL = '';
