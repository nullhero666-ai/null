# LUMILEX development instructions (Codex/AI agents)

Mission: maintain the existing functional eight-mode web game while preparing secure scalable web infrastructure. Protect existing puzzle content and never remove features without a passing replacement.

1. Read `README.md`, `docs/GAME_MODES_AND_RULES.md`, `docs/SECURITY_LIMITATIONS.md`, and `docs/LAUNCH_CHECKLIST.md` before changing files.
2. User-approved UI: navy/white, calm blue accents, large equal-sized tiles, professional mobile-first design, minimal animations, light and dark themes.
3. Only PvP 1v1 and Team 2v2 are level locked (Classic 15, 20). Other six available immediately. No pay-to-unlock.
4. Never label AI opponents as human, never fake queues or real online rooms, never claim a cloud leaderboard exists without a backend.
5. Do not claim globally scalable: current `server.py` keeps rooms in memory. For production, require durable authoritative room coordination and backed-up account storage.
6. Run `node --check app.js`, `python -m py_compile server.py`, `python -m unittest discover -s tests -v`, and multiplayer integration with a running server. Document evidence.
7. Preserve keyboard + touch + drag support, 320px phone widths, reduced-motion preferences, and accessible button labels.
8. Never leak secrets in frontend or `config.js`; never disable server-side word/score validation.
9. All work must include tests and a clear rollback path. Fix defects, avoid superficial UI-only changes.
10. Public launch is blocked until every mandatory item in `docs/LAUNCH_CHECKLIST.md` is addressed.
