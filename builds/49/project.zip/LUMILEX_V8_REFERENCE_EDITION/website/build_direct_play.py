"""Create a direct-open, one-file solo game with an intro Play button."""
from pathlib import Path
root=Path(__file__).parent
s=(root/'LUMILEX_OFFLINE.html').read_text()
css='''<style>
#direct-intro{position:fixed;inset:0;z-index:9999;overflow-y:auto;display:flex;justify-content:center;align-items:center;padding:20px;background:radial-gradient(circle at 70% 12%,#1b5193 0%,transparent 50%),linear-gradient(145deg,#071629,#122e54);font-family:Inter,system-ui,sans-serif;color:#fff}
#direct-intro .intro-wrap{display:grid;grid-template-columns:1.15fr .85fr;gap:46px;align-items:center;width:min(930px,100%)}
#direct-intro .eyebrow{display:inline-block;color:#9ad8ff;border:1px solid #82c9ff55;background:#147cf51a;border-radius:99px;padding:9px 15px;font-size:11px;letter-spacing:.08em;font-weight:850}
#direct-intro h1{font-size:clamp(38px,6vw,65px);letter-spacing:-.05em;line-height:1.05;margin:23px 0 15px}
#direct-intro h1 span{color:#6ed4ff}
#direct-intro p{color:#b4d0ea;font-size:16px;line-height:1.7}
#direct-intro button{width:min(350px,100%);min-height:56px;margin-top:26px;border:0;border-radius:13px;color:#fff;font-size:16px;font-weight:850;background:linear-gradient(120deg,#227cf6,#00b4ef);cursor:pointer}
#direct-intro .notes{display:block;font-size:12px;color:#92b5d3;margin-top:18px}
#direct-intro .tiles{display:grid;grid-template-columns:repeat(2,1fr);gap:12px;max-width:300px;width:100%;justify-self:center;transform:rotate(3deg)}
#direct-intro .tiles span{display:grid;place-items:center;aspect-ratio:1;border-radius:18px;background:#fff;color:#13263b;font-size:clamp(55px,10vw,92px);font-weight:900;box-shadow:inset 0 -5px 0 #d9e5ef}
@media(max-width:650px){#direct-intro{align-items:flex-start;padding:34px 20px}#direct-intro .intro-wrap{grid-template-columns:1fr;gap:30px}#direct-intro .tiles{max-width:250px}#direct-intro button{width:100%}#direct-intro h1{margin-top:18px}}
</style>'''
intro='''<div id="direct-intro" role="dialog" aria-modal="true" aria-label="Welcome to LUMILEX"><div class="intro-wrap"><div><span class="eyebrow">LUMILEX WORD ARENA · OFFLINE EDITION</span><h1>Find words.<br><span>Feel the win.</span></h1><p>Eight modes in one game, including six that work here without internet. Enjoy 250 Classic levels, 54 Word Searches, daily puzzles, speed rounds, AI and 36 crosswords.</p><button id="direct-start" type="button">▶ Play now — it's free</button><span class="notes">No ads · Touch and keyboard · Progress saved in this browser.<br>Real 1v1 and 2v2 need the server from the full ZIP.</span></div><div class="tiles" aria-hidden="true"><span>R</span><span>U</span><span>O</span><span>T</span></div></div></div>'''
js='<script>document.getElementById("direct-start").addEventListener("click",function(){document.getElementById("direct-intro").remove();document.querySelector("[data-act=play-classic]")?.focus();});</script>'
s=s.replace('</head>',css+'</head>').replace('<body>','<body>'+intro,1).replace('</body>',js+'</body>',1)
(root/'LUMILEX_Web_v5_Direct_Play.html').write_text(s)
(root/'LUMILEX_v7_Play.html').write_text(s)
print('Wrote direct-open HTML, bytes:',len(s.encode('utf-8')))
