# Traffic, performance and reliability architecture

## Reality check

No software can guarantee zero lag or zero glitches for unlimited world traffic. The current beta server supports real WebSocket rooms but stores all sessions, queues and matches in one Python process. A second identical replica cannot share its room state. Capacity is deliberately capped by environment variables (`MAX_WS`, `MAX_ROOMS`). Do not interpret a local smoke test as proof of 10k/100k concurrent-player readiness.

## Production target architecture

```text
US, Canada and international players
      │
      ├── Global CDN / WAF / rate limits
      │       ├── Public LUMILEX landing website
      │       ├── Game app + versioned JS/CSS + puzzle banks
      │       └── PWA and localization assets
      │
      ├── API service / managed auth
      │       ├── Identity, progress, XP, level unlocks, rewards
      │       ├── PostgreSQL with backups and migrations
      │       ├── CDN-friendly read-only daily puzzle definitions
      │       └── Privacy, moderation, abuse and support workflows
      │
      └── Realtime multiplayer coordinator
              ├── Matchmaking by region / rules
              ├── One authoritative stateful object per room
              ├── WebSocket presence and reconnect tokens
              ├── Server-validated letter path and points
              ├── Durable match result and anti-cheat events
              └── Telemetry and automated cleanup
```

Suggested implementation path: CDN for static assets; managed PostgreSQL for player data; **Cloudflare Durable Objects** (WebSocket hibernation) as an option for 1v1/2v2 rooms. A room only coordinates 2–4 players, avoiding global shared mutable state. This architecture is a plan, not code implemented in this beta package.

## Traffic engineering gates (targets, not measured guarantees)

| Measure | Pre-public target |
|---|---|
| CDN availability | >=99.9% rolling 30 days |
| Match start success | >=99% when seats complete |
| WebSocket reconnect success | >=98% for brief supported disconnections |
| Mobile game Largest Contentful Paint | <=2.5 seconds p75 on representative devices |
| Word submission acknowledgement | <=250ms p95 within the chosen region |
| Lost progress incidents | No known reproducible P0/P1 issues |
| Security | Auth, rate limits, abuse controls, third-party review |
| Backups | Automated snapshots + tested restore |

You need real production telemetry and controlled synthetic load to verify these. For a first stress target, choose a realistic concurrent-player estimate from analytics and a 2× safety margin; simulate arrival bursts, reconnect storms and room-join races. Rate-limit guesses, queued requests, and room creation. Make servers reject excess work politely rather than crash.

## Multi-region planning

- Start US and Canada with the lowest measured median/p95 round-trip latency and appropriate data residency/privacy controls.
- Keep each match in one authoritative region; never resolve simultaneous word claims independently in multiple nodes.
- Introduce additional geographic room placement only after measured demand. Put a player's profile in a stable durable datastore; separate it from ephemeral match state.
- Use staging + canary deploys, graceful room draining and protection against reconnect storms.

## Efficiency checklist

- Static site, no third-party JS, small images, compressed assets; no ad SDK.
- Use edge cache for immutable puzzle packs, and HTTP conditional requests.
- Keep one WebSocket per session, not per UI component; send only claims/changes.
- One match coordinator per room, with deterministic word validators.
- Daily puzzle computed from a stable date/seed, not regenerated per user.
- Measure actual costs for 1k/10k/100k DAU and peak active matches rather than committing to a provider blindly.

## Official references

- Cloudflare WebSocket hibernation: https://developers.cloudflare.com/durable-objects/best-practices/websockets/
- Durable Objects for stateful coordination: https://developers.cloudflare.com/durable-objects/best-practices/rules-of-durable-objects/
- AWS Games Industry Lens: https://docs.aws.amazon.com/wellarchitected/latest/games-industry-lens/
- AWS multi-AZ design: https://docs.aws.amazon.com/wellarchitected/latest/games-industry-lens/gamerel01-bp01.html
