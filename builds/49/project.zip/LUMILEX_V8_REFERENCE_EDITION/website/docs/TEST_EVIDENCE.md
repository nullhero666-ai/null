# LUMILEX web v5 — verification record (2026-11-06)

Automated checks executed in the build environment:

- 15 Python unittest tests passed: puzzle banks, existing browser gameplay, level unlock rules, website visual/functional checks, direct HTML intro/play/Classic win.
- Real multiplayer protocol exercised using independent WebSocket clients: private 1v1, private 2v2, public 2v2 matchmaking, verified score paths, duplicate-word rejection.
- Local HTTP/WebSocket smoke: 150 HTTP GET requests at 20 concurrent client tasks, 8 guest WS handshakes, zero failures, observed HTTP p95 approx 16.4ms **inside local environment only**.
- Direct HTML intro closes on Play, then Classic Level 1 completed and Level 2 unlocked in headless browser.
- Website and game layout tested at 320, 360, 390, 768 and 1100 px with zero horizontal overflow.
- Malicious Origin rejected with 403; source file request `/server.py` returned 404; `/api/health` returned 200.
- All puzzles structurally valid: 250 Classic, 54 Word Search, 36 Crossword.

Limitations: sandbox browser prohibits loopback HTTP navigation, so Chromium tests embed website and game HTML; actual HTTP routes were tested separately. Visual browser screenshots are from the embedded exact website markup and styles. No public hosting, real-device testing, multi-region stress test, managed identity/cloud saves or independent security audit has been performed. Single-node server must not be horizontally replicated as-is.
