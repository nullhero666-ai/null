# Prompt for your next VS Code + Codex session

Read AGENTS.md, README.md, docs/SCALING_ARCHITECTURE.md and docs/SECURITY_LIMITATIONS.md. Start with a repo audit; don't replace functioning features. Build the next production milestone:

- Introduce a verified guest/account identity and cloud progress schema with migrations, tests and rollback support. Keep local solo mode available without a login.
- Define server-side completion receipts and transaction-safe XP/coins rewards. Enforce Classic level 15 for 1v1 and level 20 for 2v2 on **server**, not only in JavaScript.
- Make all match commands idempotent and race-safe. Implement reconnect grace period, synchronized clock and reliable join/leave outcomes.
- Propose an incremental migration from single-node Python state to per-room durable coordination, not multi-replica Python with separate RAM.
- Add staging observability, automatic integration tests and 2x forecast concurrency load plan.

Never announce the service is production ready unless test evidence and the release checklist support it. After each stage, report changed files, exact tests, limitations, and next acceptance criteria.
