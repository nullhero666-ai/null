# Security and privacy: beta limitations and release blockers

The local app has secure-random per-tab guest tokens, same-origin WebSocket checks, a message-size limit, basic throttling, score/path verification, response security headers and capped client counts. This is **not the same as authenticated accounts** and does not provide launch-grade anti-cheat or global persistence.

## Must fix before public accounts or high traffic

1. **Durable identity:** OAuth/passkeys or managed authentication, server-held session state, logout and secure cookie/token rotation.
2. **Server-authoritative progression:** Never trust a browser to tell the server that Classic Level 15/20 was completed. Persist verified results server-side, enforce unlock checks on room create/queue/join.
3. **Cloud saves:** transactional progression, optimistic concurrency / idempotency keys, conflict handling across devices, export/delete flows.
4. **Realtime integrity:** reconnect grace window, signed match tickets, replay/sequence numbers, rate limits, auditable anti-cheat events, disconnect policies.
5. **Abuse controls:** nickname filtering, reporting/blocking, banned accounts, detection of automated clients, rate limiting at CDN and API.
6. **Privacy & policies:** privacy policy, terms, retention schedule, Canadian PIPEDA assessment, U.S. COPPA if directed to children under 13, EU/UK GDPR and child-safety obligations where applicable; legal review of store/marketing claims.
7. **Operations:** secrets rotation, server audit logs without storing message content unnecessarily, incident runbooks, backup and restore tests.
8. **Payments:** current Game Pass is a placeholder **without payment checkout**. Do not collect payment information until implementation and compliance are ready.

## Current guest caveats

- Solo progress is stored in localStorage and may disappear if browser storage is cleared; export backup is available.
- Progress is not synchronized across devices or verified by backend. A technical user could bypass client-only multiplayer level locks using direct WebSocket requests.
- Single-node rooms disappear after server restart. Private room codes only work on the same server instance.
- No real-money purchases, no verified cloud leaderboard, no production age gating or safety moderation system.
- No external ad/tracking SDK in this build.

**Security sign-off is a hard release gate, not a suggestion.**
