# Deployment Guide — Web first

## 0. Current launch status

The included build is suitable for local testing and a controlled **single-instance beta**. It is **not approved for a high-traffic global release** without the scaling/security steps documented below. No cloud service has been deployed from this project.

## 1. Run locally and validate

1. Install Python 3.10+ and `python -m pip install -r requirements.txt`.
2. Run `python server.py` and visit `http://127.0.0.1:8765/`.
3. Press **Play now**. Verify Classic Level 1, Word Search, AI, Daily, Speed and Crossword.
4. For real rooms use two separate browsers/devices on the same server; after reaching the required Classic levels, create a private 1v1 room and join by code, then start the match.
5. Run the tests in `README.md`.

## 2. Deploy a PRIVATE beta on a managed container service

Use a provider that supports long-lived WebSockets and HTTPS (for example a paid container web service). Connect the repository and select the included `Dockerfile`. Set its HTTP port to `8765`, check `/api/health`, and use **one replica only**.

Environment:

```env
HOST=0.0.0.0
PORT=8765
MAX_WS=250
MAX_ROOMS=200
MAX_IP_WS=20
# Public browser origins only; specify exact site origin(s) if necessary
ALLOWED_ORIGINS=https://YOUR-DOMAIN.example
# Set to 1 ONLY if hosting platform overwrites X-Forwarded-For, else keep 0
TRUST_PROXY=0
```

**Important:** Behind some proxies many real users may share a proxy source IP. Tune `MAX_IP_WS` and `TRUST_PROXY` according to verified provider headers; do not blindly trust user-supplied `X-Forwarded-For`. Attach your custom domain, DNS and TLS. Verify `/api/health`, first puzzle, private room creation, friend join, and match completion over `wss://`.

Do not put passwords, private keys, tokens or payments information into `config.js`.

## 3. Split game assets from the room service for scale

Host `landing.html`, `landing.css`, `landing.js`, `index.html`, `style.css`, `app.js`, JSON puzzle banks, `config.js`, manifest, service worker and icons on a global static CDN. Upload only **public** static files. Do **not** upload `server.py`, `.env`, tests, or database exports into the public bucket.

Set the CDN-served `config.js` to:

```js
window.LUMILEX_WS_URL = 'wss://arena.YOUR-DOMAIN.example/ws';
```

Set the room server `ALLOWED_ORIGINS=https://play.YOUR-DOMAIN.example`. Verify that the platform allows WebSocket upgrades and preserves legitimate Origin information. Keep static response security headers and caching policies equivalent to the local server. The homepage and game entrypoints should be no-store; versioned JS/CSS/data can be cached long-term after adding fingerprinted names.

## 4. Production backend migration, mandatory for public growth

The single-process server is intentionally a working reference rather than an autoscaling system. Migrate to an authoritative multi-room coordinator such as Cloudflare Workers + one Durable Object per room (or a managed distributed match-state service). Add durable account identity, persistent progress, rankings, reconnect grace period and server-authoritative unlocks. See `SCALING_ARCHITECTURE.md` and `SECURITY_LIMITATIONS.md`.

## 5. Release slowly

Development → closed beta → controlled US/Canada web release → evaluate actual concurrent users, p95 ack latency, error rate, retention, and hosting costs → regional expansion. Mobile apps only after website traction and safety/reliability gates are met.

## 6. Operational checks

- Before every deploy: unit/integration tests, static analysis, content validation and staging review.
- During deploy: error-rate dashboard, WebSocket connection count, match joins, reconnects and HTTP latency.
- Have rollback artifact ready, confirm backup restore and disable matchmaking if the room service becomes unhealthy.
- Keep solo modes accessible if online battles are unavailable.
