# Gameplay and navigation specification

- **Landing route `/`:** public site with **Play now** CTA, interactive-feel Classic preview, all eight modes, three-step guide, invite-code form and connectivity indicator.
- **Game route `/index.html?play=1`:** home with profile, XP, currencies (in-game only), Classic continue card, eight mode cards, navbar (Home/Levels/Multiplayer/Ranking/Rewards/Settings), and light/dark toggle.
- **Deep links:** `?mode=classic|search|speed|ai|daily|cross|pvp|team`. An invite `/?room=ABC234` redirects to the in-game multiplayer join form `index.html?room=ABC234`.
- **Classic:** clue + letter tiles, tap or keyboard, Enter to submit, use each tile at most once, 250 sequential levels; no timer.
- **Word Search:** find each themed word along straight adjacent tiles, by drag or typing, 54 sequential levels.
- **Speed:** select 30/60/120 seconds; correct words score points; local best.
- **AI:** select Easy, Normal, Hard. The opponent is explicitly computer-controlled.
- **Daily:** fixed puzzle selection by UTC date; local daily result.
- **Crossword:** select clue, type its answer, solve intersecting words, 36 sequential puzzles.
- **PvP 1v1:** after reaching Classic Level 15, create private six-character room or enter public queue. Shared search board; first verified claim owns a word. 105-second match or finish when all words claimed.
- **Team 2v2:** after reaching Classic Level 20, two Blue and two Gold players; same shared board. Alternating teammates who claim consecutive words for same team earn a +15 server-calculated relay bonus. Real humans only (no fake matching).
- **No mode locks for:** Classic, Word Search, Speed, AI, Daily, Crossword. No paid mode unlocks.

## User flow

Website → Play → Game Home → Choose a Mode → Solve → Results → Next Level/Replay. Multiplayer: Lobby/Match Menu → Create/Join/Queue → Wait for required real seats → Host starts (private) or automatic start (public) → Live score → Final result.

## Operational disclaimers

The provided client uses local progress and the included beta server doesn't verify that Classic levels were completed. A production backend must validate these level gates independently. Team match score and duplicate-word claims **are** verified by the beta server.
