# Next milestone: Real Worldwide Ranking Service

The v7 UI is intentionally a **clearly labelled preview**. To replace demo leaderboard records with real user data, implement:

1. **Authentication:** Secure account/guest upgrade, stable player IDs, session security, deletion and privacy preferences.
2. **Self-reported region:** Optional `country_code` and `city_id`, validated against a trusted city catalog with canonical IDs; no silent geolocation.
3. **Verified results:** PvP match ends must be signed/recorded on the authoritative match server. Never trust `rating`, `wins`, or `rank` sent by the client or imported local progress.
4. **Ranked eligibility:** PvP at Classic 15, 2v2 at Classic 20, enforced on the server with account-based progress.
5. **Season history:** season IDs, rankings per mode, rating adjustments, replay prevention, ties, sanctions, resets and appeal audit trails.
6. **Leaderboards:** Materialized/cached top-N global/country/city rankings with cursor pagination and current-player position endpoints.
7. **Fairness:** Cooldowns, anti-farming, bot checks, disconnect handling, rematch controls and monitoring for collusion.
8. **Scale:** Load test to forecast concurrency; use a managed database, cache and stateful real-time room coordinator. Make analytics and leaderboards resilient to partial outage.
9. **Controls:** Moderation for display names, abuse reporting, age/privacy guardrails for young users, data retention and consent.

Suggested API contract for the future backend:

```text
GET /api/v1/rankings?season=active&scope=global|country|city&mode=1v1|2v2&cursor=...
GET /api/v1/rankings/me?season=active&mode=1v1|2v2
GET /api/v1/seasons/active
GET /api/v1/profile/me
PATCH /api/v1/profile/me
```

Response samples must include `season_id`, `as_of_utc`, `source="verified"`, `rank`, `rating`, `games_played`, and a stable pseudonymous player ID. Display "unavailable" rather than fabricated scores if the production service is down.
