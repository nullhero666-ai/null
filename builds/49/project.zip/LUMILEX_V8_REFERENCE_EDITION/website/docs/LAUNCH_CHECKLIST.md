# Launch readiness — checkboxes

## Current beta checks (implemented / tested locally)

- [x] Marketing-style intro with Play Now, mode overview and room-code entry.
- [x] Eight game modes connected to gameplay screens (PvP/2v2 require running server).
- [x] 250 Classic, 54 Word Search and 36 Crossword records pass structural checks.
- [x] Classic level 15 / team level 20 client unlock UX.
- [x] Private and public WebSocket matchmaking tested across separate clients.
- [x] Mobile-friendly layout, keyboard/tap/swipe input, light/dark themes.
- [x] Offline solo HTML export, browser-local progress, progress export/import.
- [x] No interrupting advertisements.
- [x] Server origin/size/basic request controls and readiness endpoint.
- [x] Small local HTTP + WebSocket smoke test.

## Public web launch blockers — must complete

- [ ] Real account authentication and recovery.
- [ ] Verified server-side level progression, rewards and matchmaking authorization.
- [ ] Production-safe region-aware match coordinator (no in-memory single-process rooms).
- [ ] Persisted live results, retry-safe awards, rankings and cloud saves.
- [ ] Match reconnect handling and recovery after server/edge restart.
- [ ] Distributed cache/DB setup with backups and tested restoration.
- [ ] Privacy terms, policies, legal/content review, and child-safety obligations.
- [ ] Independent security audit, OWASP review and automation/bot abuse mitigation.
- [ ] Real device matrix for iOS Safari, Android Chrome, Windows, macOS, Linux.
- [ ] Load tests at forecast peak CCU with 2x safety factor, including reconnect surge.
- [ ] Observability: live dashboards, alerts, error budgets, on-call runbook.
- [ ] Canary rollout and rehearsed rollback.
- [ ] Content editorial review for all 340 puzzle records, accessible clues and licensing.
- [ ] Controlled US/Canada beta and measured retention, match satisfaction, and spend.

## App development later

- [ ] Web beta success and sustained stable usage.
- [ ] Android and iOS release plan and store compliance check.
- [ ] Reuse shared logic; avoid rewriting game rules in native platforms.
