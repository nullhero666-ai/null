import json,random,re,collections
from pathlib import Path
ROOT=Path(__file__).parent
old=json.loads((ROOT/'puzzles.json').read_text())
THEMES=collections.defaultdict(set)
for p in old:
    for w in p['words']:
        if 4<=len(w)<=8 and w.isalpha():THEMES[p['theme']].add(w)
MORE='''
Nature: LEAF BARK ROOT TREE SEED SOIL STEM BUSH DEER WOLF MOSS PINE RAIN WIND DUSK DAWN LAKE POND ROCK CLOUD RIVER BEACH STORM MIST OCEAN GRASS FROST BLAZE FLORA FAUNA PLUME BIRCH MAPLE CEDAR
Food: PEAR PLUM PEACH GRAPE LEMON LIME MANGO MELON BREAD TOAST PASTA RICE MILK CHEESE CREAM JUICE HONEY OLIVE BEANS ONION CORN SUGAR CANDY SWEET TACO SOUP STEW CHILI BACON PIZZA APPLE
Space: MOON STAR SUNS MARS VENUS EARTH ORBIT COMET METEOR GALAXY COSMOS SATURN NEBULA PLUTO ECLIPSE ROCKET PLANET SOLAR LUNAR SPACE ASTRAL
Animals: LION TIGER BEAR WOLF OTTER MOUSE HORSE SHEEP ZEBRA PANDA WHALE SHARK SNAKE CAMEL GOOSE EAGLE ROBIN FROG CRAB DUCK SWAN GOAT DEER TOAD
Travel: TRAIN PLANE BOAT SHIP BIKE RIDE TAXI ROAD PATH TRACK ROUTE TRAIL MAPS HOTEL CABIN CAMP HIKE BEACH TOUR BAGGAGE PASSPORT
Music: SONG TUNE BEAT DRUM BASS JAZZ PIANO GUITAR VIOLIN DANCE CHOIR NOTE LYRIC CHORD SOUND VOICE MELODY RHYTHM
Weather: RAIN SNOW WIND FOGS HAIL STORM THUNDER CLOUD DRIZZLE SUNNY BREEZE FROST MIST SHOWER RAINBOW
Colors: BLUE PINK GOLD GRAY WHITE BLACK GREEN INDIGO ORANGE PURPLE SILVER SCARLET CYAN AMBER CORAL IVORY BRONZE
Sports: GOLF BALL GOAL TEAM RACE JUMP RUNS SWIM DIVE SKATE TENNIS SOCCER BOXING RUGBY MATCH SCORE TRACK SPRINT
Home: ROOM DOOR DESK CHAIR TABLE LAMP SOFA CLOCK BRUSH SPOON PLATE TOWEL SHELF WINDOW CARPET MIRROR PILLOW BLANKET
Technology: CODE DATA WIFI CHIP MOUSE SCREEN PHONE ROBOT LASER PIXEL CLOUD LOGIN EMAIL SERVER CIRCUIT VECTOR CAMERA SIGNAL BINARY
Arts: PAINT BRUSH DRAW CLAY FRAME DESIGN CRAFT PAPER COLOR INKED PHOTO IMAGE SCENE MURAL SHAPE STAGE FILM MUSIC ACTOR
Ocean: WAVE TIDE SAND SURF FISH CORAL SHELL PEARL SHORE BEACH REEF SHARK WHALE DOLPHIN DIVER SAIL BOAT
Garden: ROSE LILY HERB MINT ROOT SEED SOIL WATER BLOOM PETAL DAISY TULIP VINE LEAF STEM FLOWER
World: CITY TOWN ROAD PARK BRIDGE RIVER FOREST DESERT CANYON VALLEY ISLAND MOUNTAIN VILLAGE TEMPLE MARKET
Science: ATOM CELL LABS TEST LASER WAVE LIGHT SOUND FORCE ENERGY METAL GAS SKY CHEMISTRY SPACE GRAVITY FORMULA
'''
for line in MORE.strip().splitlines():
    theme,ws=line.split(':',1)
    THEMES[theme].update(w for w in ws.split() if 4<=len(w)<=8)
# Specific, high-signal short clues for early play and crossword generation.
CLUES={
 'TREE':'A tall plant with a trunk','WIND':'Moving air','RAIN':'Water falling from clouds','MOON':'Earth’s natural satellite','STAR':'A bright object in the night sky','SUNS':'Stars at the center of solar systems','BEAR':'A large furry animal','LION':'Big cat with a mane','ROSE':'A flower often given as a gift','LAMP':'A device that gives indoor light','BOAT':'A small vessel on water','SHIP':'A large vessel at sea','FISH':'An animal with gills','BIRD':'An animal with feathers','BOOK':'Pages bound for reading','DESK':'A table for working','DOOR':'An entrance panel','CAKE':'Sweet baked dessert','MILK':'White drink from dairy','PEAR':'A sweet bell-shaped fruit','PLUM':'Small purple fruit','RICE':'A grain eaten worldwide','LEAF':'Green part of a plant','ROOT':'Part of a plant below ground','SEED':'A plant’s beginning','MOSS':'Soft green ground cover','LAKE':'An inland body of water','POND':'A small body of still water','SNOW':'Frozen flakes falling from the sky','DUSK':'Time just after sunset','DAWN':'The beginning of day','ROCK':'A hard natural stone','RAINBOW':'Colorful arc seen after rain','CLOUD':'A visible mass of water droplets','WAVE':'A moving swell of water','TIDE':'Regular rise and fall of the sea','SAND':'Tiny grains on a beach','SURF':'Breaking waves near the shore','TACO':'A folded tortilla with filling','SOUP':'Liquid food served in a bowl','BREAD':'Food baked from flour','TOAST':'Bread browned by heat','PIZZA':'Baked flatbread with toppings','APPLE':'Round fruit that can be red or green','GRAPE':'Small fruit that grows in bunches','LEMON':'A sour yellow citrus fruit','LIME':'A sour green citrus fruit','HONEY':'Sweet food made by bees','SUGAR':'Sweet crystals used in cooking','ONION':'Vegetable that can make you cry','CORN':'Yellow kernels on a cob','BEAT':'Steady rhythm in music','DRUM':'Instrument struck for rhythm','SONG':'Music with sung words','TUNE':'A memorable melody','BASS':'Low musical sound','PIANO':'Keyboard musical instrument','GUITAR':'Six-stringed musical instrument','VIOLIN':'String instrument held under the chin','DANCE':'Move your body to music','CHOIR':'Group of singers','NOTE':'A single musical sound','GOAL':'Point you try to score','TEAM':'People working together to win','RACE':'Competition of speed','GOLF':'Sport played with clubs','BALL':'Round object used in sports','SKATE':'Glide on ice or wheels','TENNIS':'Racket sport across a net','SOCCER':'Sport played with a ball and feet','JUMP':'Leave the ground using your legs','DIVE':'Enter water headfirst','WIFI':'Wireless network connection','CHIP':'Small piece of electronic circuitry','CODE':'Instructions written for computers','DATA':'Information stored or processed','ROBOT':'Machine that performs tasks','PHONE':'Device used to make calls','EMAIL':'A digital message','PIXEL':'A tiny dot on a display','LASER':'A narrow concentrated beam of light','SERVER':'Computer providing services over a network','METAL':'Hard material like iron','ATOM':'Small building block of matter','CELL':'Basic unit of living things','FORCE':'Push or pull on an object','ENERGY':'Ability to do work','LIGHT':'Visible form of electromagnetic energy','SOUND':'Vibrations perceived by ears','BLUE':'Color of a clear daytime sky','PINK':'Pale shade of red','GOLD':'Precious yellow metal','GRAY':'Color between black and white','WHITE':'Color of fresh snow','BLACK':'Color of a dark night','GREEN':'Color of many leaves','ORANGE':'Citrus fruit and its color','CORAL':'Colorful sea animal colony','IVORY':'Creamy-white shade','CHAIR':'Seat with a back','TABLE':'Furniture with a flat top','CLOCK':'Device that shows the time','SHELF':'Flat place used to store objects','WINDOW':'Opening filled with glass','MIRROR':'Surface that reflects your face','PILLOW':'Soft support for your head','CARPET':'Floor covering made of fabric','TOWEL':'Cloth used for drying','SPOON':'Utensil for eating soup','PLATE':'Flat dish used for food','BRUSH':'Tool with bristles','PLANE':'Aircraft with wings','TRAIN':'Vehicle that runs on rails','BIKE':'Two-wheeled vehicle','TAXI':'Car hired with a driver','ROAD':'Way for vehicles','PATH':'Route for walking','TRAIL':'Marked route through nature','HOTEL':'Place to stay while traveling','CAMP':'Temporary outdoor place to stay','HIKE':'Long walk through nature','CITY':'Large populated settlement','TOWN':'Settlement smaller than a city','PARK':'Public green space','BRIDGE':'Structure crossing a river or road','FOREST':'Large area full of trees','DESERT':'Dry region with little rain','VALLEY':'Low land between hills','ISLAND':'Land surrounded by water','TEMPLE':'Building used for worship','MARKET':'Place where goods are sold','FRAME':'Border around a picture','PHOTO':'Image taken with a camera','PAINT':'Colored liquid used by artists','DRAW':'Make a picture using lines','CRAFT':'Activity of making things by hand','PAPER':'Thin material used for writing','SHAPE':'Outline of an object','CAMERA':'Device used to take photos','SCENE':'Setting of a story or film','FILM':'Motion picture','ACTOR':'Person performing a role','FLOWER':'Colorful part of many plants','PETAL':'Part of a flower','VINE':'Climbing plant with long stems','BLOOM':'A flower opening','HERB':'Plant used for flavor or medicine','MINT':'A fragrant green herb','WATER':'Liquid essential for life','SHARK':'Large fish with sharp teeth','WHALE':'Huge sea mammal','DOLPHIN':'Intelligent marine mammal','SHELL':'Hard outer cover of some sea animals','REEF':'Underwater ridge formed by coral','SHORE':'Land beside water','SOLAR':'Related to the sun','LUNAR':'Related to the moon','PLANET':'A world orbiting a star','ORBIT':'Path around a larger object','COMET':'Icy object with a glowing tail','GALAXY':'Giant system of stars','ROCKET':'Vehicle propelled by engines','SPACE':'Region beyond Earth’s atmosphere','VENUS':'Second planet from the Sun','MARS':'Red planet','EARTH':'Our home planet'
}
words={}
for t in sorted(THEMES):
 for w in sorted(THEMES[t]):
  words.setdefault(w,t)
# Favor easy concrete / short words in earlier levels.
items=[(w,CLUES.get(w,f'A word connected to {t.lower()}'),t) for w,t in words.items() if 4<=len(w)<=8]
items.sort(key=lambda x:(0 if len(x[0])==4 else 1 if len(x[0])==5 else 2, 0 if x[0] in CLUES else 1,x[0]))
# Guarantee early levels have hand-written clue descriptions.
early=[w for w in ['TREE','WIND','RAIN','MOON','STAR','BEAR','ROSE','LAMP','BOAT','FISH','BIRD','BOOK','DESK','DOOR','CAKE','MILK','PEAR','PLUM','RICE','LEAF','ROOT','SEED','MOSS','LAKE','POND','SNOW','DUSK','DAWN','ROCK','WAVE','TIDE','SAND','SURF','TACO','SOUP','BEAT','DRUM','SONG','TUNE','BASS','GOAL','TEAM','RACE','GOLF','BALL','JUMP','DIVE','WIFI','CHIP','CODE','DATA','BLUE','PINK','GOLD','GRAY','LIME','LION','WOLF','MINT','ROAD','TOWN','PARK'] if w in words]
seen=set(early)
ordered=[i for w in early for i in items if i[0]==w] + [i for i in items if i[0] not in seen]
assert len(ordered)>=250,len(ordered)
levels=[]
for idx,(w,clue,t) in enumerate(ordered[:250],1):
 n=2 if idx<=55 else 3 if idx<=200 else 4
 if len(w)>n*n:n=3
 rng=random.Random(idx*21019+97)
 chars=list(w)
 # Some decoys only when larger boards. Still correct word fully available exactly once for each repeated letter.
 vowels='AEIOU';freq='RSTLNDCMPGHF'
 while len(chars)<n*n:chars.append(rng.choice(vowels if idx%3==0 else freq))
 rng.shuffle(chars)
 levels.append(dict(level=idx,size=n,letters=''.join(chars),answer=w,clue=clue,category=t,difficulty='Easy' if idx<=55 else 'Medium' if idx<=200 else 'Expert'))
(ROOT/'classic.json').write_text(json.dumps(levels,indent=2),encoding='utf8')
# Build compact crossword puzzles with a definite crossing for each down word.
usable=[(w,c) for w,c in CLUES.items() if 4<=len(w)<=7]
byword=dict(usable)
crosses=[]
for seed in range(1,37):
 rng=random.Random(seed*7891)
 solved=False
 for _ in range(2000):
  horizontal=rng.choice(usable)
  w=horizontal[0]
  if len(w)<5:continue
  idx1,idx2=sorted(rng.sample(range(len(w)),2))
  if idx2-idx1<2:continue
  candidates=[]
  for colidx in [idx1,idx2]:
   matches=[(z,c,j) for z,c in usable if z!=w and (j for j in []) is not None for j,v in enumerate(z) if v==w[colidx] and 1<=j<=3 and len(z)-j<=5]
   if not matches:break
   rng.shuffle(matches);candidates.append(matches)
  if len(candidates)<2:continue
  a,b=candidates[0][0],next((x for x in candidates[1] if x[0]!=candidates[0][0][0]),None)
  if not b:continue
  size=9;row=4;left=max(0, (size-len(w))//2)
  placements=[]
  placements.append({'id':'1A','number':1,'direction':'across','answer':w,'clue':horizontal[1],'cells':[row*size+left+k for k in range(len(w))]})
  for k,(word,clue,index) in enumerate([a,b]):
   col=left+[idx1,idx2][k]
   start=row-index
   if start<0 or start+len(word)>size:break
   placements.append({'id':f'{k+2}D','number':k+2,'direction':'down','answer':word,'clue':clue,'cells':[(start+j)*size+col for j in range(len(word))]})
  if len(placements)!=3:continue
  grid={}
  for p in placements:
   for k,l in zip(p['cells'],p['answer']):
    if k in grid and grid[k]!=l:break
    grid[k]=l
   else:continue
   break
  if len(grid)<sum(map(lambda p:len(p['answer']),placements))-2:continue
  if any(x['answer'] in (p['answer'] for z in crosses for p in z['words']) for x in placements): continue
  crosses.append({'id':seed,'size':size,'words':placements,'solution':''.join(grid.get(i,'#') for i in range(size*size)),'theme':'Mini Crossword'})
  solved=True;break
 if not solved:raise Exception(f'Could not create crossword #{seed}')
(ROOT/'crosswords.json').write_text(json.dumps(crosses,indent=2),encoding='utf8')
print('Classic:',len(levels),'unique',len(set(x['answer'] for x in levels)),'Crossword:',len(crosses),'Wordsearch:',len(old))
