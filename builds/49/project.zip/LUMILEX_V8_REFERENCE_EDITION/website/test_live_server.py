"""Local integration tests for the included multiplayer server."""
import asyncio, json, secrets, os
from aiohttp import ClientSession
URL=os.environ.get('TEST_URL','http://127.0.0.1:8765')
BANK=json.load(open('puzzles.json'))

def token():return secrets.token_hex(24)

async def match_message(ws,predicate,timeout=3):
    async with asyncio.timeout(timeout):
        while True:
            msg=await ws.receive_json()
            if predicate(msg):return msg

async def connect(s,name):
    ws=await s.ws_connect(URL+'/ws')
    await ws.send_json({'type':'hello','token':token(),'name':name})
    await match_message(ws,lambda x:x.get('type')=='hello')
    return ws

async def test_private(s,mode):
    count=2 if mode=='1v1' else 4
    socks=[await connect(s,'P'+str(i)) for i in range(count)]
    await socks[0].send_json({'type':'create','mode':mode})
    lobby=await match_message(socks[0],lambda x:x.get('type')=='room')
    code=lobby['code']
    assert len(code)==6
    for i in range(1,count):
        await socks[i].send_json({'type':'join','code':code})
        r=await match_message(socks[i],lambda x:x.get('type')=='room')
        assert r['code']==code and r['status']=='lobby'
    await socks[0].send_json({'type':'start'})
    running=[await match_message(ws,lambda x:x.get('status')=='playing') for ws in socks]
    grid=running[0]['puzzle'];assert len(grid['grid'])==grid['size']**2
    assert all(x['puzzle']['id']==grid['id'] for x in running)
    assert [p['team'] for p in running[0]['players']]==['A','B']*(count//2)
    level=BANK[grid['id']-1]
    path=level['solutions'][0]
    await socks[0].send_json({'type':'guess','path':path})
    positive=await match_message(socks[0],lambda x:x.get('type')=='feedback')
    assert positive['ok'],positive
    updated=await match_message(socks[0],lambda x:x.get('type')=='room' and len(x.get('claims',{}))==1)
    assert len(updated['claims'])==1
    assert updated['players'][0]['score']==len(level['words'][0])*10
    await socks[1].send_json({'type':'guess','path':path})
    denied=await match_message(socks[1],lambda x:x.get('type')=='feedback')
    assert denied['ok'] is False,denied
    if mode=='2v2':
        await socks[2].send_json({'type':'guess','path':level['solutions'][1]})
        bonus=await match_message(socks[2],lambda x:x.get('type')=='feedback')
        assert bonus['ok'] and 'RELAY' in bonus['message'],bonus
        second=await match_message(socks[2],lambda x:x.get('type')=='room' and len(x.get('claims',{}))==2)
        assert second['players'][2]['score']==len(level['words'][1])*10+15,second
    await socks[1].send_json({'type':'guess','path':[0,3,9]})
    # invalid guess never scores
    await asyncio.sleep(.25)
    for ws in socks:await ws.close()
    print(mode,'OK:',code,'path checked, one claim scored, duplicate rejected')

async def test_public(s):
    ws=[await connect(s,'Q'+str(i)) for i in range(4)]
    for sock in ws:
        await sock.send_json({'type':'queue','mode':'2v2'})
    games=[await match_message(sock,lambda x:x.get('status')=='playing',timeout=5) for sock in ws]
    assert len({x['code'] for x in games})==1
    assert all(x['private'] is False for x in games)
    print('Public 2v2 matchmaking OK:',games[0]['code'])
    for sock in ws:await sock.close()

async def main():
    async with ClientSession() as session:
        response=await session.get(URL+'/api/health');assert response.status==200
        await test_private(session,'1v1')
        await test_private(session,'2v2')
        await test_public(session)
    print('ALL LIVE MATCH SERVER TESTS PASSED')
asyncio.run(main())
