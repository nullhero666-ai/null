'use strict';
const params = new URLSearchParams(location.search);
const invited = (params.get('room') || '').toUpperCase();
if (/^[A-HJ-NP-Z2-9]{6}$/.test(invited)) location.replace('/index.html?room=' + encodeURIComponent(invited));
const y = document.getElementById('year');
if (y) y.textContent = String(new Date().getFullYear());
const form = document.getElementById('join-form');
form?.addEventListener('invalid', event => {document.getElementById('join-error').hidden=false},true);
form?.addEventListener('submit', event => {
  event.preventDefault();
  const code = (document.getElementById('room').value || '').trim().toUpperCase();
  if (!/^[A-HJ-NP-Z2-9]{6}$/.test(code)) { document.getElementById('join-error').hidden = false; return; }
  location.href = '/index.html?room=' + encodeURIComponent(code);
});
(async () => {
 const status = document.getElementById('server-status');
 if (!status) return;
 try {
  const response = await fetch('/api/health', {cache:'no-store',signal:AbortSignal.timeout(3500)});
  if (!response.ok) throw Error('unavailable');
  status.textContent = '● Live room server connected';status.classList.add('online');
 } catch {status.textContent='● Solo games are available. Live rooms require the game server.';status.classList.add('offline')}
})();
