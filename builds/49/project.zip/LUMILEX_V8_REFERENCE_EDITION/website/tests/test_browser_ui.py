"""Offline end-to-end browser test, using an about:blank inline build.
The runner blocks navigation to local/loopback URLs, so test with set_content.
"""
from pathlib import Path
import unittest
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]

class BrowserTest(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.ctx=sync_playwright().start()
  cls.browser=cls.ctx.chromium.launch(headless=True, executable_path='/usr/bin/chromium' if Path('/usr/bin/chromium').exists() else None,args=['--no-sandbox'])
  cls.html=(ROOT/'LUMILEX_OFFLINE.html').read_text()
 @classmethod
 def tearDownClass(cls):
  cls.browser.close();cls.ctx.stop()
 def setUp(self):
  self.page=self.browser.new_page(viewport={'width':390,'height':844})
  self.errors=[]
  self.page.on('pageerror',lambda err:self.errors.append(str(err)))
  self.page.set_content(self.html,wait_until='load')
 def tearDown(self):
  self.assertFalse(self.errors,self.errors)
  self.page.close()
 def test_home_all_modes_and_locks(self):
  p=self.page
  self.assertEqual(p.locator('.mode-card').count(),8)
  self.assertIn('Unlock at Level 15',p.locator('[data-mode="pvp"]').inner_text())
  self.assertIn('Unlock at Level 20',p.locator('[data-mode="team"]').inner_text())
  for mode in ('classic','search','speed','ai','daily','cross'):
   self.assertNotIn('Unlock at',p.locator(f'[data-mode="{mode}"]').inner_text())
  self.assertEqual(p.evaluate('document.documentElement.scrollWidth-document.documentElement.clientWidth'),0)
 def test_classic_input_and_progress(self):
  p=self.page;p.locator('[data-act="play-classic"]').click()
  self.assertEqual(p.locator('.letter-tile').count(),4)
  for k in 'TREE':p.locator(f'[data-act="key"][data-key="{k}"]').click()
  p.locator('.game-controls [data-act="submit"]').click()
  self.assertIn('Word solved!',p.locator('.modal h2').inner_text())
  p.locator('[data-act="next-classic"]').click()
  self.assertIn('Level 2',p.locator('.page-header h1').inner_text())
 def test_20_classic_unlocks_both_multiplayer_modes(self):
  p=self.page
  result=p.evaluate('''() => { for(let n=1;n<=19;n++){startClassic(n);const w=state.game.p.answer;const letters=state.game.p.letters;let used=new Set();state.selected=[...w].map(c=>{const i=[...letters].findIndex((v,j)=>v===c&&!used.has(j));used.add(i);return i});classicSubmit();closeModal()}home();return {level:classicLevel(),pvp:isUnlocked('pvp'),team:isUnlocked('team'),count:profile.classicDone.length}}''')
  self.assertEqual(result,{'level':20,'pvp':True,'team':True,'count':19})
  self.assertNotIn('Unlock at',p.locator('[data-mode="team"]').inner_text())
 def test_word_search_keyboard_and_completion(self):
  p=self.page;p.locator('[data-mode="search"]').click()
  words=p.evaluate('state.game.p.words')
  for w in words:
   p.locator('#word-entry').fill(w)
   p.locator('.game-controls [data-act="submit"]').click()
  self.assertIn('Well played!',p.locator('.modal h2').inner_text())
  self.assertIn(1,p.evaluate('profile.searchDone'))
 def test_word_search_drag(self):
  p=self.page;p.locator('[data-mode="search"]').click()
  path=p.evaluate('state.game.p.solutions[0]')
  first=p.locator(f'[data-cell="{path[0]}"]').bounding_box()
  p.mouse.move(first['x']+first['width']/2,first['y']+first['height']/2)
  p.mouse.down()
  for i in path[1:]:
   box=p.locator(f'[data-cell="{i}"]').bounding_box()
   p.mouse.move(box['x']+box['width']/2,box['y']+box['height']/2,steps=4)
  p.mouse.up()
  self.assertEqual(len(p.evaluate('Object.keys(state.game.found)')),1)
 def test_crossword_clues(self):
  p=self.page;p.locator('[data-mode="cross"]').click()
  self.assertEqual(p.locator('.cross-cell').count(),81)
  answers=p.evaluate('state.game.p.words.map(w=>w.answer)')
  for ans in answers:
   p.locator('#cross-entry').fill(ans)
   p.locator('.game-controls [data-act="submit"]').click()
  self.assertIn('Crossword solved!',p.locator('.modal h2').inner_text())
 def test_daily_speed_ai_and_settings(self):
  p=self.page
  p.locator('[data-mode="daily"]').click()
  self.assertIn('Daily Challenge',p.locator('.page-header h1').inner_text())
  p.locator('.bottom-nav [data-to="home"]').click()
  p.locator('[data-mode="speed"]').click()
  self.assertIn('Choose your speed',p.locator('.modal h2').inner_text())
  p.locator('[data-act="choose-speed"][data-level="30"]').click()
  self.assertEqual(p.evaluate('state.game.duration'),30)
  p.evaluate('state.game.expiresAt=Date.now()-1000;tick()')
  self.assertIn("Time's up!",p.locator('.modal h2').inner_text())
  p.locator('[data-act="close-modal"]').click()
  p.locator('.bottom-nav [data-to="home"]').click()
  p.locator('[data-mode="ai"]').click()
  p.locator('[data-act="choose-ai"][data-level="hard"]').click()
  self.assertEqual(p.evaluate('state.game.botDifficulty'),'hard')
  p.evaluate('state.game.botNext=Date.now()-1;botMove()')
  self.assertGreaterEqual(len(p.evaluate('Object.keys(state.game.found)')),1)
  p.locator('.bottom-nav [data-to="settings"]').click()
  p.locator('[data-act="theme"]').click()
  self.assertEqual(p.evaluate('profile.theme'),'dark')
  self.assertEqual(p.evaluate('document.documentElement.dataset.theme'),'dark')
  p.locator('#player-name').fill('Tester')
  p.locator('[data-act="save-name"]').click()
  self.assertEqual(p.evaluate('profile.name'),'Tester')
 def test_responsive_mobile_widths(self):
  p=self.page
  for w in (320,360,390,768,1100):
   p.set_viewport_size({'width':w,'height':800})
   self.assertEqual(p.evaluate('document.documentElement.scrollWidth-document.documentElement.clientWidth'),0,f'Overflow {w}')

if __name__=='__main__':unittest.main()
