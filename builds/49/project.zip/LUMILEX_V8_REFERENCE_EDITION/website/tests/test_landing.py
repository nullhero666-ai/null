"""Landing page visual/interaction checks using inline HTML (sandbox blocks loopback browsing)."""
from pathlib import Path
import unittest
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
class WebsiteSmoke(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.pw=sync_playwright().start()
  cls.browser=cls.pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium' if Path('/usr/bin/chromium').exists() else None,args=['--no-sandbox'])
  cls.html=(ROOT/'landing.html').read_text()
  cls.html=cls.html.replace('<link rel="stylesheet" href="landing.css">','<style>'+ (ROOT/'landing.css').read_text() +'</style>')
  cls.html=cls.html.replace('<script src="landing.js" defer></script>','')
 @classmethod
 def tearDownClass(cls):
  cls.browser.close();cls.pw.stop()
 def setUp(self):
  self.p=self.browser.new_page(viewport={'width':390,'height':844})
  self.errors=[]
  self.p.on('pageerror',lambda e:self.errors.append(str(e)))
  self.p.set_content(self.html,wait_until='load')
  self.p.add_script_tag(content=(ROOT/'landing.js').read_text())
 def tearDown(self):
  self.assertFalse(self.errors,self.errors)
  self.p.close()
 def test_modes_and_play(self):
  p=self.p
  self.assertIn('Find words.',p.locator('h1').inner_text())
  self.assertEqual(p.locator('.mode').count(),8)
  self.assertIn('level 15',p.locator('.mode[href*="pvp"]').inner_text())
  self.assertIn('level 20',p.locator('.mode[href*="team"]').inner_text())
  self.assertIn('Available now',p.locator('.mode[href*="speed"]').inner_text())
  self.assertEqual(p.locator('.hero-actions .cta-primary').get_attribute('href'),'/index.html?play=1')
  self.assertEqual(p.locator('.room-help').get_attribute('href'),'/index.html?play=1&tab=multiplayer')
 def test_room_validation(self):
  p=self.p
  p.locator('#room').fill('ZZZZZZ') # Z is permitted
  p.locator('#room').fill('ABCI23') # I deliberately excluded from invite alphabet
  p.locator('#join-form button').click()
  self.assertFalse(p.locator('#join-error').is_hidden())
 def test_mobile_layout(self):
  p=self.p
  for width in (320,360,390,768,1100):
   p.set_viewport_size({'width':width,'height':900})
   self.assertEqual(p.evaluate('document.documentElement.scrollWidth-document.documentElement.clientWidth'),0,f'overflow width={width}')
if __name__=='__main__':unittest.main()
