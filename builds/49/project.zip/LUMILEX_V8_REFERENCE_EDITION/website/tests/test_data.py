"""Check that the shipped puzzle content is internally valid and solvable."""
import collections, json, pathlib, unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]

class PuzzleDataTests(unittest.TestCase):
 def test_classic_250(self):
  items=json.loads((ROOT/'classic.json').read_text());self.assertEqual(len(items),250)
  for n,p in enumerate(items,1):
   self.assertEqual(p['level'],n)
   self.assertEqual(len(p['letters']),p['size']**2)
   self.assertTrue(collections.Counter(p['answer'])<=collections.Counter(p['letters']),f"Level {n} impossible")
   self.assertTrue(p['clue'])
 def test_wordsearch_54(self):
  items=json.loads((ROOT/'puzzles.json').read_text());self.assertEqual(len(items),54)
  for p in items:
   n=p['size'];self.assertEqual(len(p['grid']),n*n)
   self.assertEqual(len(p['words']),len(p['solutions']))
   self.assertEqual(len(set(p['words'])),len(p['words']))
   for word,path in zip(p['words'],p['solutions']):
    self.assertEqual(len(path),len(word))
    self.assertEqual(''.join(p['grid'][i] for i in path),word)
    self.assertEqual(len(set(path)),len(path))
    self.assertTrue(all(0<=i<n*n for i in path))
    for a,b in zip(path,path[1:]):
     x,y=divmod(a,n);xx,yy=divmod(b,n)
     self.assertTrue(max(abs(x-xx),abs(y-yy))==1)
    if len(path)>2:
     step=path[1]-path[0];self.assertTrue(all(path[i+1]-path[i]==step for i in range(len(path)-1)))
 def test_crossword_36(self):
  items=json.loads((ROOT/'crosswords.json').read_text());self.assertEqual(len(items),36)
  for p in items:
   self.assertEqual(len(p['solution']),p['size']**2)
   for w in p['words']:
    self.assertEqual(len(w['cells']),len(w['answer']))
    self.assertTrue(w['clue'])
    self.assertEqual(''.join(p['solution'][i] for i in w['cells']),w['answer'])

if __name__=='__main__':unittest.main()
