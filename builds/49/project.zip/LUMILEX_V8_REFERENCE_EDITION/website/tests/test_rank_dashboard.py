"""Ranking design, tab interactions, persistence, and mobile viewport QA."""
from pathlib import Path
import unittest
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]

class RankingDashboardTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pw = sync_playwright().start()
        cls.browser = cls.pw.chromium.launch(
            headless=True,
            executable_path='/usr/bin/chromium',
            args=['--no-sandbox','--disable-dev-shm-usage'],
        )
        # The direct file is self-contained, so tests avoid localhost restrictions.
        cls.html = (ROOT / 'LUMILEX_Web_v5_Direct_Play.html').read_text()

    @classmethod
    def tearDownClass(cls):
        cls.browser.close()
        cls.pw.stop()

    def test_scope_filters_and_location(self):
        page = self.browser.new_page(viewport={'width':390,'height':844})
        errors = []
        page.on('pageerror', lambda exc: errors.append(str(exc)))
        try:
            page.set_content(self.html, wait_until='load')
            page.locator('#direct-start').click()
            page.locator('.bottom-nav [data-to="ranking"]').click()
            self.assertEqual(page.locator('.rank-tab').count(),3)
            self.assertTrue(page.locator('.rank-hero-card').is_visible())
            self.assertIn('Sample entries',page.locator('#rank-scope-wrapper').inner_text())
            page.locator('[data-scope="city"]').click()
            self.assertIn('Set your city',page.locator('#rank-scope-content').inner_text())
            page.locator('.bottom-nav [data-to="settings"]').click()
            page.locator('#player-country').fill('Canada')
            page.locator('#player-city').fill('Toronto')
            page.locator('[data-act="save-name"]').click()
            page.locator('.bottom-nav [data-to="ranking"]').click()
            page.locator('[data-scope="city"]').click()
            self.assertIn('Toronto preview',page.locator('#scope-title').inner_text())
            self.assertGreater(page.locator('.rank-table-row').count(),0)
            self.assertEqual(page.evaluate('document.documentElement.scrollWidth - document.documentElement.clientWidth'),0)
            self.assertFalse(errors,errors)
        finally:
            page.close()

    def test_responsive_rank_and_word_search(self):
        for width in (320,390,768,1440):
            page=self.browser.new_page(viewport={'width':width,'height':850})
            try:
                page.set_content(self.html,wait_until='load')
                page.locator('#direct-start').click()
                page.locator('.bottom-nav [data-to="ranking"]').click()
                self.assertEqual(page.evaluate('document.documentElement.scrollWidth - document.documentElement.clientWidth'),0)
                page.locator('.bottom-nav [data-to="home"]').click()
                page.locator('[data-mode="search"]').click()
                self.assertEqual(page.evaluate('document.documentElement.scrollWidth - document.documentElement.clientWidth'),0)
                if width<=740:
                    self.assertLess(page.locator('.game-sidebar').bounding_box()['y'],page.locator('.game-panel').bounding_box()['y'])
            finally:
                page.close()

if __name__ == '__main__':
    unittest.main()
