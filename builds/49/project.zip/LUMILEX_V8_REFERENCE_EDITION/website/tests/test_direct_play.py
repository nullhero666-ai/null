"""Single-file direct-open intro and Classic win flow."""
import unittest
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
class DirectPlayTest(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.pw=sync_playwright().start();cls.browser=cls.pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium' if Path('/usr/bin/chromium').exists() else None,args=['--no-sandbox'])
 @classmethod
 def tearDownClass(cls):cls.browser.close();cls.pw.stop()
 def test_intro_and_classic(self):
  p=self.browser.new_page(viewport={'width':360,'height':780});errors=[];p.on('pageerror',lambda x:errors.append(str(x)))
  p.set_content((ROOT/'LUMILEX_Web_v5_Direct_Play.html').read_text(),wait_until='load')
  self.assertTrue(p.locator('#direct-intro').is_visible())
  p.locator('#direct-start').click()
  self.assertEqual(p.locator('#direct-intro').count(),0)
  self.assertEqual(p.locator('.mode-card').count(),8)
  p.locator('[data-act="play-classic"]').click()
  for key in 'TREE':p.locator('[data-act="key"][data-key="'+key+'"]').click()
  p.locator('.game-controls [data-act="submit"]').click()
  self.assertIn('Word solved!',p.locator('.modal h2').inner_text())
  self.assertFalse(errors,errors);p.close()
if __name__=='__main__':unittest.main()
