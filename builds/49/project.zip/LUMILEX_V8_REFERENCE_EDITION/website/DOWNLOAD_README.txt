LUMILEX v7 - WEBSITE + PYTHON BACKEND + SOURCE CODE

1. Extract this ZIP.
2. Open LUMILEX_Web_v7_Pro in VS Code.
3. Install Python 3.11+ and run:
   python -m pip install -r requirements.txt
   python server.py
4. Open http://127.0.0.1:8765/ in a browser.
5. Read README.md and START_HERE.md.

For offline solo play, open LUMILEX_v7_Play.html. Real multiplayer requires the server. Global ranks are sample data until a database-backed ranking service is added.
