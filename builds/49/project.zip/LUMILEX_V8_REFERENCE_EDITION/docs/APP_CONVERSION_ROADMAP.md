# LUMILEX App Conversion Roadmap

## Current status

**Functional local prototype:** website + offline puzzle game, native wrapper scaffolding, single-node Python PvP sample server. **Missing:** signed Android/iOS builds, online accounts, durable user progress, live global rankings, high-availability match backend, payments, app-store certification and native device QA.

## Stage A — App packaging and design (prioritize Android first on Linux)

- Install Capacitor dependencies, create Android native project and run on emulator and real device.
- Verify all 8 mode navigation routes and that offline modes survive airplane mode + app restart.
- Fix touch target sizes, text overflow, rotated screen behavior, status-bar/safe-area insets, virtual keyboards and accessibility.
- Provide accessible app icon, splash, back-navigation, and safe recovery from lost connectivity.

**Gate:** Android release candidate installs, boots, resumes, updates and completes typical solo sessions on supported devices. No uncaught JS errors.

## Stage B — Backend release engineering

- Host static site on CDN, publish backend HTTPS/WSS.
- Add auth (passkeys/email/Google/Apple sign-in as appropriate) and secure session tokens with rotation and revocation.
- Database: profiles, privacy preferences, progress, match history, ratings, seasons, location preference, audit events.
- Matchmaking: idempotent queues, disconnect/rejoin, timeouts, anti-cheat, server-verified word paths, ELO/Glicko-like transparent rules.
- Ranking: server-computed global/country/city views with privacy-conscious opt-in location; abandon fake competitor entries in public release.
- Load and fault tests: stress concurrent rooms, packet loss, regional failure and backlog handling.

**Gate:** successful 1v1 and 2v2 end-to-end across separate real devices and different networks, verified persistent ratings and reliable recovery.

## Stage C — Launch Android

- Create production appId/package name, signing key backup, privacy/support pages, Play Console listing, ratings and content declaration.
- Make sure the latest required target API is configured (Android 16 / API 36 for new apps as of Aug 31, 2026).
- Complete closed/internal testing, crash monitoring and gradual rollout.

## Stage D — Launch iOS

- Acquire Mac/Xcode environment; `npx cap add ios` / `npx cap sync ios`, test on iPhones.
- Test native app-like interactions and App Review minimum functionality; review all privacy and account controls.
- Complete TestFlight, screenshots and App Store Connect review; gradual release.

## Store launch is not a guarantee

Store submission and public availability require developer accounts, approvals, infrastructure and real device validation; a Capacitor wrapper alone does not make a high-scale production app.
