#!/usr/bin/env bash
set -euo pipefail
SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TARGET="${1:-$HOME/Downloads/LUMILEX_v7_Mobile_Conversion_Starter}"
if [ ! -f "$TARGET/package.json" ]; then
  echo "ERROR: package.json not found: $TARGET"
  echo "Pass your existing Capacitor project folder as an argument."
  exit 1
fi
if [ ! -d "$TARGET/android" ]; then
  echo "ERROR: android/ missing: $TARGET"
  echo "Open the original project (where npx cap add android succeeded), or run CREATE_ANDROID_PROJECT.sh here."
  exit 1
fi
if [ ! -f "$SOURCE_DIR/www/index.html" ]; then
  echo "ERROR: game files missing from $SOURCE_DIR/www"
  exit 1
fi
if [ "$(cd "$TARGET" && pwd)" = "$SOURCE_DIR" ]; then
  echo "ERROR: Source and destination are the same project."
  exit 1
fi
BACKUP="$TARGET/www.backup.$(date +%Y%m%d_%H%M%S)"
if [ -d "$TARGET/www" ]; then
  cp -a "$TARGET/www" "$BACKUP"
  echo "Previous game files backed up to: $BACKUP"
fi
mkdir -p "$TARGET/www"
cp -a "$SOURCE_DIR/www/." "$TARGET/www/"
cd "$TARGET"
if [ ! -x node_modules/.bin/cap ]; then
  echo 'Installing Node/Capacitor packages (internet required)...'
  npm install
fi
npm run check
npx cap sync android
printf '\nSUCCESS: LUMILEX v8 game files copied and synchronized.\nOpen in Android Studio:\n  %s/android\n\n' "$TARGET"
