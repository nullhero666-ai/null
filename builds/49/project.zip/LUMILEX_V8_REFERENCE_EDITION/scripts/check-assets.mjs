import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve('www');
for (const file of ['index.html','app.js','style.css','config.js','classic.json','puzzles.json','crosswords.json','icon-192.png','icon-512.png','assets/coastal-escape.svg','assets/starlit-peaks.svg','assets/forest-path.svg','assets/golden-dunes.svg','assets/bloom-garden.svg']) {
  if (!fs.existsSync(path.join(root,file))) throw new Error(`Missing app asset: ${file}`);
}
const banks=[['classic.json',250],['puzzles.json',54],['crosswords.json',36]];
for (const [name,expected] of banks) {
  const puzzles=JSON.parse(fs.readFileSync(path.join(root,name),'utf8'));
  if (!Array.isArray(puzzles)||puzzles.length!==expected) throw new Error(`Bad puzzle bank ${name}: ${puzzles.length}`);
  console.log(`${name}: ${puzzles.length} puzzles OK`);
}
const config=fs.readFileSync(path.join(root,'config.js'),'utf8');
if (/\b(secret|api_key)\s*=\s*['"][^'"]+['"]/i.test(config)) throw new Error('Potential secret in public config');
console.log('All native web assets present.');
