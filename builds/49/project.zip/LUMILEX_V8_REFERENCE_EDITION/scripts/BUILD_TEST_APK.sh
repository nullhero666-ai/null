#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
if [ ! -f android/gradlew ]; then
  echo 'ERROR: android/gradlew not found. Run CREATE_ANDROID_PROJECT.sh first.'
  exit 1
fi
npm run check
npx cap sync android
cd android
chmod +x gradlew
./gradlew assembleDebug
printf '\nAPK build completed. File: %s/app/build/outputs/apk/debug/app-debug.apk\n' "$PWD"
