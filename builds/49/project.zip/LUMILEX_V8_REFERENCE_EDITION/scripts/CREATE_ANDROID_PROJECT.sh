#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
if ! command -v node >/dev/null || ! command -v npm >/dev/null; then
  echo 'ERROR: Install Node.js 22+ and npm first.'
  exit 1
fi
npm install
npm run check
if [ ! -d android ]; then
  npx cap add android
fi
npx cap sync android
printf '\nSUCCESS: Android Studio project created. Open this folder in Android Studio:\n  %s/android\n' "$PWD"
