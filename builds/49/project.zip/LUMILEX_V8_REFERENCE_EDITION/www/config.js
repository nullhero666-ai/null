// For native PvP, configure a deployed HTTPS/WSS backend after authentication is ready.
// Leave blank for offline solo play; do NOT put secrets in this file.
window.LUMILEX_WS_URL = '';
