# LUMILEX Word Arena — v7 Professional Web UI

A web-first, mobile-friendly word puzzle game, including a redesigned Ranking Arena, seven league tiers, and the existing eight gameplay modes.

## Play immediately

Open `LUMILEX_v7_Play.html` in a current browser. It contains all offline solo content and a Play button without requiring an installation, account or server. Real-player PvP and 2v2 modes require the included server.

## Full website and local multiplayer

Requires Python 3.10 or newer:

```sh
python -m pip install -r requirements.txt
python server.py
```

Open `http://127.0.0.1:8765/` for the welcome page, or `http://127.0.0.1:8765/index.html` for the game. The welcome page and application share the same source files. The Python server can support private 1v1 and 2v2 rooms and public queues **on one instance**. It is not an internet-scale backend.

## Modes

| Mode | Description | Requirement |
|---|---|---|
| Classic | 250 word-clue levels, keyboard and letter tiles | Immediately available |
| Word Search | 54 themed grid puzzles, typing and dragging | Immediately available |
| Speed | Timed word search | Immediately available |
| AI | Computer opponent | Immediately available |
| Daily | UTC date-based puzzle | Immediately available |
| Crossword | 36 clue-based puzzles | Immediately available |
| PvP Duel | 1v1 online rooms | Reach Classic level 15; server required |
| Team Battle | 2v2 online rooms | Reach Classic level 20; server required |

## The redesigned v7 Ranking Arena

The ranking dashboard has a clean tier shield, practice score progress, stats cards, a three-player podium, league roadmap, and a single Global / Country / City table with working scope tabs. Country and city are **optional, manually entered** in Settings.

**Transparency:** The leaderboard contains example players and sample point totals. It is labelled as a development preview. Your displayed practice league is a local estimate; it is *not a real multiplayer rank*. Live worldwide rankings require verified accounts, a persistent database, server-scored results, season administration, and anti-cheat measures. Do not market this prototype as an official global leaderboard.

## UI changes

- Wider, full-bleed desktop website hero and more efficient desktop card grid.
- Consistent typography, spacing, light/dark contrast and interactive states.
- Mobile word targets are compact and appear above the grid; instructions are expandable.
- Accessible navigation controls and touch-friendly elements.
- Supported widths tested: 320px, 390px, 768px, 1440px.
- Progress stored locally in the browser; export/import retained.

## Source structure

```text
landing.html   landing.css    landing.js    marketing entry and Play button
index.html     style.css      app.js        web client
classic.json   puzzles.json   crosswords.json   level content
server.py      requirements.txt             beta single-node live rooms
sw.js          manifest.webmanifest        PWA cache / manifest
LUMILEX_v7_Play.html                  direct-open game with intro
LUMILEX_OFFLINE.html                   alternate offline build
tests/                                  automated data, browser and ranking checks
docs/                                   deployment, security and scaling guidance
build_offline.py / build_direct_play.py  regenerate self-contained HTML editions
```

## Checks completed for this build

```sh
node --check app.js
node --check landing.js
python -m unittest discover -s tests -v
python test_live_server.py   # run separately while python server.py is running
```

17 local unit/browser checks passed, including gameplay and ranking interactions, and the multiplayer client tests passed against one local server. These are development tests, not large-scale load, security, accessibility or production platform certifications.

## Before any high-traffic public launch

Read `docs/SECURITY_LIMITATIONS.md`, `docs/SCALING_ARCHITECTURE.md`, and `docs/LAUNCH_CHECKLIST.md`. Add user accounts, privacy controls, server-side level validation, verified ranking points and seasons, persistent match state, centralized monitoring, rate limiting, audits and representative load tests. Do **not** run multiple replicas of the current in-memory room server without first replacing its room coordination layer.
