"""LUMILEX multiplayer and static hosting, Python 3.10+, aiohttp.
Usage: pip install -r requirements.txt; python server.py
For online play use a HTTPS/WSS-capable deployment and configure reverse proxy.
"""
import asyncio
import json
import os
import random
import re
import secrets
import time
from urllib.parse import urlsplit
from pathlib import Path
from aiohttp import web, WSMsgType

ROOT=Path(__file__).parent
PUZZLES=json.loads((ROOT/'puzzles.json').read_text(encoding='utf-8'))
ROOMS={}
SESSIONS={}
QUEUES={'1v1':[], '2v2':[]}
MAX_SIZE=32768
GAME_DURATION=105
MAX_AGE=3600
# Single-node safety limits. Scaling this process to many workers requires a shared room coordinator.
MAX_WS=int(os.getenv('MAX_WS','250'))
MAX_ROOMS=int(os.getenv('MAX_ROOMS','200'))
MAX_IP_WS=int(os.getenv('MAX_IP_WS','20'))
ACTIVE_WS=set()
IP_WEBSOCKETS={}
ALLOWED_ORIGINS={v.strip() for v in os.getenv('ALLOWED_ORIGINS','').split(',') if v.strip()}
TRUST_PROXY=os.getenv('TRUST_PROXY','0')=='1' # Only behind a reverse proxy that overwrites X-Forwarded-For.



def identity(token):
    return bool(re.fullmatch(r'[A-Za-z0-9_-]{20,80}',token or ''))

def code_new():
    while True:
        code=''.join(secrets.choice('ABCDEFGHJKLMNPQRSTUVWXYZ23456789') for _ in range(6))
        if code not in ROOMS:return code

def assign_team(room):
    return 'A' if len(room['players'])%2==0 else 'B'

def player_meta(p):
    return {'name':p['name'],'team':p['team'],'score':p['score'],'online':p['ws'] is not None, 'id':p['id']}

def snapshot(room,viewer):
    return {
        'type':'room','code':room['code'],'mode':room['mode'],'private':room['private'],
        'status':room['status'],'host':room['host']==viewer,'yourId':viewer,
        'players':[player_meta(p) for p in room['players'].values()],
        'puzzle':{k:v for k,v in room['puzzle'].items() if k!='solutions'} if room['puzzle'] else None,
        'claims':room['claims'],'endsAt':room['ends_at'],
        'winner':room.get('winner'),'reason':room.get('reason'),
    }

async def send(ws,payload):
    if ws is not None and not ws.closed:
        try:await ws.send_json(payload)
        except Exception:pass

async def broadcast(room):
    for key,p in list(room['players'].items()):
        await send(p['ws'],snapshot(room,key))

def valid_path(puzzle,path):
    if not isinstance(path,list) or not 3<=len(path)<=puzzle['size']:return None
    if any(type(x)!=int or x<0 or x>=puzzle['size']**2 for x in path):return None
    if len(set(path))!=len(path):return None
    n=puzzle['size']
    a=path[0];b=path[1]
    r,c=divmod(a,n);rr,cc=divmod(b,n)
    dr=rr-r;dc=cc-c
    if abs(dr)>1 or abs(dc)>1 or dr==0 and dc==0:return None
    for idx,value in enumerate(path):
        r2,c2=divmod(value,n)
        if (r2,c2)!=(r+idx*dr,c+idx*dc):return None
    return ''.join(puzzle['grid'][x] for x in path)

def new_room(mode,private,creator):
    code=code_new()
    room={'code':code,'mode':mode,'private':private,'host':creator['id'],
          'players':{},'status':'lobby','puzzle':None,'claims':{},'ends_at':None,
          'created':time.time(),'last':time.time(),'winner':None,'reason':None,'last_claimed':None}
    ROOMS[code]=room
    return room

def room_capacity(room):return 2 if room['mode']=='1v1' else 4

async def join_room(session,room):
    rid=session['room']
    if rid and rid in ROOMS and rid!=room['code']:
        await leave_room(session)
    old=room['players'].get(session['id'])
    if old:
        if old['ws'] is not None and old['ws']!=session['ws']:
            await send(old['ws'],{'type':'error','message':'Your session was opened in another tab.'})
            await old['ws'].close()
        old['ws']=session['ws'];old['name']=session['name']
    else:
        if room['status']!='lobby' or len(room['players'])>=room_capacity(room):
            return False
        room['players'][session['id']]={'id':session['id'],'name':session['name'],'team':assign_team(room),'score':0,'ws':session['ws'],'last_guess':0}
    session['room']=room['code'];room['last']=time.time()
    await broadcast(room)
    return True

async def leave_room(session):
    code=session.get('room');session['room']=None
    if not code or code not in ROOMS:return
    room=ROOMS[code]
    if room['status']=='lobby':
        room['players'].pop(session['id'],None)
        if room['host']==session['id'] and room['players']:
            room['host']=next(iter(room['players']))
        if not room['players']:
            ROOMS.pop(code,None);return
    else:
        if session['id'] in room['players']:
            room['players'][session['id']]['ws']=None
    room['last']=time.time()
    await broadcast(room)

async def finish(room,reason='time'):
    if room['status']!='playing':return
    room['status']='finished';room['reason']=reason
    scores={'A':sum(p['score'] for p in room['players'].values() if p['team']=='A'),
            'B':sum(p['score'] for p in room['players'].values() if p['team']=='B')}
    room['winner']='draw' if scores['A']==scores['B'] else max(scores,key=scores.get)
    room['last']=time.time()
    await broadcast(room)

async def timer(room):
    await asyncio.sleep(max(0,room['ends_at']-time.time()))
    await finish(room)

async def start_game(room):
    if room['status']!='lobby' or len(room['players'])!=room_capacity(room) or any(p['ws'] is None or p['ws'].closed for p in room['players'].values()):return False
    room['status']='playing';room['claims']={};room['last_claimed']=None
    room['puzzle']=random.choice(PUZZLES[20:])
    room['ends_at']=time.time()+GAME_DURATION
    for p in room['players'].values():p['score']=0
    await broadcast(room)
    asyncio.create_task(timer(room))
    return True

async def queue_match(session,mode):
    if session['room']:await leave_room(session)
    for q in QUEUES.values():
        if session['id'] in q:q.remove(session['id'])
    queue=QUEUES[mode];queue.append(session['id'])
    needed=2 if mode=='1v1' else 4
    queue[:]=[key for key in queue if key in SESSIONS and SESSIONS[key]['ws'] is not None and not SESSIONS[key]['room']]
    if len(queue)<needed:
        await send(session['ws'],{'type':'queued','mode':mode,'count':len(queue),'required':needed})
        return
    keys=[queue.pop(0) for _ in range(needed)]
    room=new_room(mode,False,SESSIONS[keys[0]])
    for key in keys:
        await join_room(SESSIONS[key],room)
    await start_game(room)

async def socket_handler(request):
    # Same-origin only unless the exact public origin is explicitly permitted.
    # Per-tab guest tokens are not durable accounts or a production auth mechanism.
    origin=request.headers.get('Origin','')
    if origin:
        parsed=urlsplit(origin)
        same_origin=(parsed.scheme in ('http','https') and parsed.netloc==request.host)
        if not same_origin and origin not in ALLOWED_ORIGINS:
            raise web.HTTPForbidden(text='Cross-origin WebSocket denied')
    ip=request.remote or 'unknown'
    if TRUST_PROXY and request.headers.get('X-Forwarded-For'):
        ip=request.headers['X-Forwarded-For'].split(',')[0].strip() or ip
    if len(ACTIVE_WS)>=MAX_WS or IP_WEBSOCKETS.get(ip,0)>=MAX_IP_WS:
        raise web.HTTPServiceUnavailable(text='The room server is full. Please retry shortly.',headers={'Retry-After':'10'})
    ws=web.WebSocketResponse(heartbeat=22,max_msg_size=MAX_SIZE)
    await ws.prepare(request)
    ACTIVE_WS.add(ws);IP_WEBSOCKETS[ip]=IP_WEBSOCKETS.get(ip,0)+1
    session=None
    try:
        async for msg in ws:
            if msg.type!=WSMsgType.TEXT:continue
            try:payload=json.loads(msg.data)
            except Exception:continue
            if not isinstance(payload,dict):continue
            typ=payload.get('type')
            if typ=='hello':
                token=payload.get('token','')
                if not identity(token):
                    await send(ws,{'type':'error','message':'Invalid session token.'});continue
                name=str(payload.get('name','Player')).strip()[:16]
                name=''.join(x for x in name if x.isalnum() or x in ' _-').strip() or 'Player'
                if token in SESSIONS and SESSIONS[token]['ws'] not in (None,ws):
                    old=SESSIONS[token]['ws'];await old.close()
                session=SESSIONS.setdefault(token,{'id':token,'room':None,'ws':ws,'name':name,'burst':[]})
                session['ws']=ws;session['name']=name
                await send(ws,{'type':'hello','id':token})
                if session['room'] and session['room'] in ROOMS:
                    await join_room(session,ROOMS[session['room']])
                continue
            if not session:
                await send(ws,{'type':'error','message':'Say hello first.'});continue
            if typ in ('create','join','queue','start'):
                now=time.monotonic()
                burst=session.setdefault('burst',[])
                burst[:]=[t for t in burst if now-t<5]
                if len(burst)>=12:
                    await send(ws,{'type':'error','message':'Too many requests. Try again in a moment.'});continue
                burst.append(now)
            if typ=='create':
                mode=payload.get('mode')
                if mode not in ('1v1','2v2'):continue
                if len(ROOMS)>=MAX_ROOMS:
                    await send(ws,{'type':'error','message':'Rooms are busy. Retry in a moment.'});continue
                if session['room']:await leave_room(session)
                room=new_room(mode,True,session)
                await join_room(session,room)
            elif typ=='join':
                code=str(payload.get('code','')).strip().upper()
                room=ROOMS.get(code)
                if not room:
                    await send(ws,{'type':'error','message':'Room not found. Check the code.'});continue
                if not await join_room(session,room):
                    await send(ws,{'type':'error','message':'This room is full or already in progress.'})
            elif typ=='queue':
                if payload.get('mode') in ('1v1','2v2'):
                    if len(ROOMS)>=MAX_ROOMS:
                        await send(ws,{'type':'error','message':'Matchmaking is busy. Retry shortly.'});continue
                    await queue_match(session,payload['mode'])
            elif typ=='cancel_queue':
                for q in QUEUES.values():
                    if session['id'] in q:q.remove(session['id'])
                await send(ws,{'type':'unqueue'})
            elif typ=='leave':
                await leave_room(session)
            elif typ=='start':
                room=ROOMS.get(session['room'])
                if room and room['host']==session['id']:
                    if not await start_game(room):
                        await send(ws,{'type':'error','message':f'Need exactly {room_capacity(room)} players to start.'})
            elif typ=='guess':
                room=ROOMS.get(session['room'])
                if not room or room['status']!='playing' or time.time()>room['ends_at']:continue
                p=room['players'].get(session['id']);now=time.time()
                if not p or now-p['last_guess']<.14:continue
                p['last_guess']=now
                word=valid_path(room['puzzle'],payload.get('path'))
                if not word or word not in room['puzzle']['words']:
                    await send(ws,{'type':'feedback','ok':False,'message':'Not a target word'});continue
                if word in room['claims']:
                    await send(ws,{'type':'feedback','ok':False,'message':'Already claimed'});continue
                relay=15 if room['mode']=='2v2' and room['last_claimed'] and room['last_claimed']['team']==p['team'] and room['last_claimed']['id']!=session['id'] else 0
                points=len(word)*10+relay
                room['last_claimed']={'team':p['team'],'id':session['id']}
                room['claims'][word]={'team':p['team'],'player':p['name'],'path':payload['path'],'points':points,'relay':relay}
                p['score']+=points
                await send(ws,{'type':'feedback','ok':True,'message':f'+{points} points'+(' · TEAM RELAY!' if relay else '')})
                await broadcast(room)
                if len(room['claims'])==len(room['puzzle']['words']):
                    await finish(room,'all_words')
    finally:
        ACTIVE_WS.discard(ws)
        IP_WEBSOCKETS[ip]=max(0,IP_WEBSOCKETS.get(ip,1)-1)
        if not IP_WEBSOCKETS[ip]:IP_WEBSOCKETS.pop(ip,None)
        if session and session.get('ws') is ws:
            session['ws']=None
            code=session.get('room')
            room=ROOMS.get(code)
            if room and session['id'] in room['players']:
                room['players'][session['id']]['ws']=None
                await broadcast(room)
            for q in QUEUES.values():
                if session['id'] in q:q.remove(session['id'])
    return ws

# Static website assets are intentionally whitelisted. Use a global CDN for public scale.
STATIC_TYPES={
    'landing.html':'text/html','landing.css':'text/css','landing.js':'text/javascript','config.js':'text/javascript',
    'index.html':'text/html','style.css':'text/css','app.js':'text/javascript',
    'puzzles.json':'application/json','classic.json':'application/json','crosswords.json':'application/json',
    'manifest.webmanifest':'application/manifest+json','sw.js':'text/javascript',
    'icon-192.png':'image/png','icon-512.png':'image/png',
    'assets/coastal-escape.svg':'image/svg+xml',
    'assets/starlit-peaks.svg':'image/svg+xml',
    'assets/forest-path.svg':'image/svg+xml',
    'assets/golden-dunes.svg':'image/svg+xml',
    'assets/bloom-garden.svg':'image/svg+xml'
}

@web.middleware
async def security_headers(request,handler):
    response=await handler(request)
    response.headers['X-Content-Type-Options']='nosniff'
    response.headers['X-Frame-Options']='DENY'
    response.headers['Referrer-Policy']='strict-origin-when-cross-origin'
    response.headers['Permissions-Policy']='camera=(), microphone=(), geolocation=()'
    response.headers['Content-Security-Policy']=(
        "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
        "img-src 'self' data:; font-src 'self'; connect-src 'self' ws: wss:; "
        "object-src 'none'; base-uri 'self'; frame-ancestors 'none'"
    )
    return response

async def static(request):
    path=request.match_info.get('path','') or 'landing.html'
    if path not in STATIC_TYPES:raise web.HTTPNotFound()
    # Do not cache entrypoints or service worker; static data and CSS get short-lived caching.
    cache='no-store' if path in ('landing.html','index.html','sw.js','config.js') else 'public, max-age=300'
    return web.FileResponse(ROOT/path,headers={'Cache-Control':cache})

async def api_health(request):
    return web.json_response({'ok':True,'service':'lumilex-single-node','rooms':len(ROOMS),'activeConnections':len(ACTIVE_WS),'limits':{'maxConnections':MAX_WS,'maxRooms':MAX_ROOMS}})

async def cleanup(app):
    while True:
        await asyncio.sleep(300)
        now=time.time()
        for code,room in list(ROOMS.items()):
            if now-room['last']>MAX_AGE or (room['status']=='finished' and now-room['last']>600):
                ROOMS.pop(code,None)
        for key,s in list(SESSIONS.items()):
            if s['ws'] is None and s['room'] not in ROOMS:SESSIONS.pop(key,None)

async def server_start(app):
    app['clean_task']=asyncio.create_task(cleanup(app))
async def server_stop(app):
    app['clean_task'].cancel()
    try: await app['clean_task']
    except asyncio.CancelledError:pass

app=web.Application(client_max_size=MAX_SIZE,middlewares=[security_headers])
app.router.add_get('/ws',socket_handler)
app.router.add_get('/api/health',api_health)
app.router.add_get('/{path:.*}',static)
app.on_startup.append(server_start)
app.on_cleanup.append(server_stop)

if __name__=='__main__':
    web.run_app(app,host=os.getenv('HOST','127.0.0.1'),port=int(os.getenv('PORT','8765')))
