# LUMILEX v8 — Update your current game

This is the updated **playable website + Capacitor Android project assets + multiplayer server source**, based on 19 reference screenshots supplied by the user. The design is original, not a copy of another game's branded artwork or monetization.

## Fastest: play in a browser without installing anything

Open `website/LUMILEX_v8_Play.html` in Chrome, Firefox, or another browser. It includes puzzles and the generated original illustrated backgrounds in a **single HTML file**. Offline modes work; multiplayer requires the server.

## Android — keep the project you already created

Open a Linux terminal in this extracted folder (the folder with `package.json`) and run:

```bash
bash scripts/UPDATE_MY_EXISTING_ANDROID_PROJECT.sh
```

This backs up your previous `www/`, copies all new game assets into your existing `~/Downloads/LUMILEX_v7_Mobile_Conversion_Starter/www/`, checks the puzzle files, and runs `npx cap sync android`.

Then open your existing Android Studio folder:

`/home/null/Downloads/LUMILEX_v7_Mobile_Conversion_Starter/android`

Use **Build → Build Bundle(s) / APK(s) → Build APK(s)**. The test APK will normally be at `android/app/build/outputs/apk/debug/app-debug.apk` inside your existing project.

If your Android project is elsewhere, pass its directory:

```bash
bash scripts/UPDATE_MY_EXISTING_ANDROID_PROJECT.sh "$HOME/path/to/your/Capacitor/project"
```

Do **not** click New Project and do **not** delete your existing `android/` folder.

## Full website

```bash
cd website
python -m pip install -r requirements.txt
python server.py
```

Then open `http://127.0.0.1:8765/` to view the web landing page and game. Room multiplayer uses that server when configured properly; native WSS requires hosting and security work.

## Important limitations

- The Android APK has **not been compiled** in this environment. This is complete updatable source, not an installable APK.
- Live worldwide ranking is **still a clearly labelled preview**; don't claim demo players are real people.
- Public online PvP/2v2 needs a hosted WSS backend, stable auth/cheat protection, and monitoring.
- Game saves use browser/local device storage; export a backup before uninstalling or clearing app data.
- The 19 reference screenshots remain yours; they were **not copied** into the source or used as ads.
